# How to Run this app
Download the repository and make sure command line points to temp folder.

Then run this code 
> python3 manage.py runserver

This is the result:

![Normal Calculator](images/home.png)
![Word Calculator](images/wordcalci.png)

